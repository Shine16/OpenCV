https://github.com/murtazahassan/OpenCV-Python-Tutorials-and-Projects

another good tutorial
https://pysource.com/2018/03/27/mouse-events-opencv-3-4-with-python-3-tutorial-27/

another good tutorial
https://www.pyimagesearch.com/2015/03/09/capturing-mouse-click-events-with-python-and-opencv/

to install one way
https://pysource.com/2019/03/15/how-to-install-python-3-and-opencv-4-on-windows/

to install opencv
-pip install opencv-python
-pip install matplotlib

file links
1 https://www.python.org/ftp/python/3.6.8/python-3.6.8-amd64.exe
2 opencv_python‑4.2.0‑cp36‑cp36m‑win_amd64.whl

Python documentation
1 The Python Tutorial — Python 3.6.10 documentation
https://docs.python.org/3.6/tutorial/index.html
2 3.6.10 Documentation
https://docs.python.org/3.6/index.html

removed environmental variable from python 2
C:\Python27\Scripts
C:\Python27\

have python environment
https://geek-university.com/python/add-python-to-the-windows-path/
https://phoenixnap.com/kb/how-to-install-python-3-windows

command - pip install opencv_python-4.1.2-cp36-cp36m-win_amd64.whl 
command - pip install numpy
command - pip install matplotlib

tutorials
1 OpenCV Tutorial - Tutorialspoint
https://www.tutorialspoint.com/opencv/index.htm
2 OpenCV Tutorial: A Guide to Learn OpenCV - PyImageSearch
https://www.pyimagesearch.com/2018/07/19/opencv-tutorial-a-guide-to-learn-opencv/
3 Python Programming Tutorials
https://pythonprogramming.net/loading-images-python-opencv-tutorial/

-----------------------
https://pythonprogramming.net/loading-images-python-opencv-tutorial/

0 loading images

using 2 libraries

matplot
https://matplotlib.org/3.2.1/api/_as_gen/matplotlib.pyplot.plot.html



how does opencv run in python
how is numpy involved


----------------------
https://pythonprogramming.net/loading-video-python-opencv-tutorial/?completed=/loading-images-python-opencv-tutorial/

1 video file

how is video file compiled
how to decompile video file
what is structure of a video file

LEARN OPENCV in 3 HOURS with Python | Including 3x Example Projects (2020)
https://www.youtube.com/watch?v=WQeoO7MI0Bs
https://github.com/murtazahassan/Learn-OpenCV-in-3-hours


https://docs.opencv.org/master/db/d28/tutorial_cascade_classifier.html
https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_objdetect/py_face_detection/py_face_detection.html
https://www.youtube.com/watch?v=3D7O_kZi8-o
https://www.youtube.com/watch?v=h56M5iUVgGs


good project, attendance taking
https://www.youtube.com/watch?v=sz25xxF_AVE


================
python libraries
https://www.lfd.uci.edu/~gohlke/pythonlibs/#opencv

on pip
https://phoenixnap.com/kb/install-pip-windows


How To Read Image-Video-Webcam [1] | OpenCV Python Tutorials for Beginners 2020 - YouTube
https://www.youtube.com/watch?v=gH_kQZo-NSk&list=PLMoSUbG1Q_r_sc0x7ndCsqdIkL7dwrmNF&index=2

Read Image-Video-Webcam - MURTAZA'S WORKSHOP
https://www.murtazahassan.com/read-image-video-webcam/

Read Image-Video-Webcam - MURTAZA'S WORKSHOP
https://www.murtazahassan.com/read-image-video-webcam/

OpenCV Course Archives - MURTAZA'S WORKSHOP
https://www.murtazahassan.com/category/opencv/opencv-course/

Face Recognition and Attendance System - MURTAZA'S WORKSHOP
https://www.murtazahassan.com/face-recognition-and-attendance-system/
